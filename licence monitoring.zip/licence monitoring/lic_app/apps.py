from django.apps import AppConfig


class LicAppConfig(AppConfig):
    name = 'lic_app'
