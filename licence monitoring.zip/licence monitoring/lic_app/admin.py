from django.contrib import admin
from lic_app.models import Testing,Tekla,authentication,Tekla_user

# Register your models here.









admin.site.register(Testing)
admin.site.register(Tekla)
admin.site.register(authentication)
admin.site.register(Tekla_user)
# admin.site.index_template = "loginPage.html"
