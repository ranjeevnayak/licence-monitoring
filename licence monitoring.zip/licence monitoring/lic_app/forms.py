from django import forms

class InputForm(forms.Form):

    soft_name = forms.CharField( max_length=100,widget = forms.TextInput(attrs = {
    'id': 'myInput',
    'placeholder':'soft_name',
    }))

    version_name = forms.CharField( max_length=100,widget = forms.TextInput(attrs = {
    'placeholder':'version_name',
    }))

    version_name = forms.CharField( max_length=100,widget = forms.TextInput(attrs = {
    'class':"datepicker",
    'placeholder':'start_date',
    }))

    version_name = forms.CharField( max_length=100,widget = forms.TextInput(attrs = {
    'class':"datepicker",
    'placeholder':'end_date',
    }))
