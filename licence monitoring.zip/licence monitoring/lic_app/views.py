from django.shortcuts import render,redirect
from django.views.generic import ListView
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from django.views.generic import (View,TemplateView)
from . import forms
from . import models
import os,re
import csv
from django import forms
##############################################################
#######              MAKE STYLISH DATE                 #######
##############################################################
def add_date_style(date):
    d = {1:'Jan',2:'Feb',3:'Mar',4:'Apr',5:'May',6:'June',7:'July',8:'Aug',9:'Sept',10:'Oct',11:'Nov',12:"Dec"}
    ans = ''
    date = str(date)
    parts = list(date.split('/'))
    day = int(parts[1])
    month = int(parts[0])
    year = int(parts[2])
    ans = str(day)+d[month]+str(year)
    return ans
##############################################################
#######             HOLD THE TIME INTERVAL             #######
##############################################################
starting="none"
ending="none"
var_temp = []
obj2_list = []
##############################################################
#######             LOGIN PAGE                         #######
##############################################################
class LoginPage(TemplateView):
    # Just set this Class Object Attribute to the template page.
    # template_name = 'app_name/site.html'
    template_name = 'loginPage.html'

    def get_context_data(self,**kwargs):
        context  = super().get_context_data(**kwargs)
        return context

##############################################################
#######             DATA INSERTING VIEW                #######
##############################################################
def home(request):
    log_file_path =os.path.join("C:\\data\\common\\LM_temp_files\\efg.txt")
    #print("log_file_path : " +log_file_path)
    read_log_file = open(log_file_path,'r')
    log_file_content = read_log_file.readlines()
    read_log_file.close()
    # print("starting to read lines")
    count=1
    for key in log_file_content:
        # remove the newline character from end of the string
        key = key.rstrip(os.linesep)
        find_text=re.search( r'\s*(\d+\/\d+\/\d+)\s+(\d+:\d+:\d+)\s+\((\w+)\)\s+(\w+):\s+\"(.*)\"\s+(.*)\@(.*)', key, re.I)

        date=find_text.group(1)
        time=find_text.group(2)
        feature=find_text.group(3)
        status=find_text.group(4)
        feature_Id=find_text.group(5)
        user_Id=find_text.group(6)
        host_ID=find_text.group(7)

        new_table = models.Tekla(date=date,time=time,feature=feature,status=status,feature_Id=feature_Id,user_Id=user_Id,host_ID=host_ID)
        new_table.save()
    return render(request,'homePageAdmin.html')

##############################################################
#######             PAGE VIEW                          #######
##############################################################
class PageView(ListView):
    model = models.Tekla
    template_name = 'homePageAdmin.html'
##############################################################
#######             FRONT VIEW                         #######
##############################################################
def front(request):
    return render(request,'frontPage.html')
##############################################################
#######             INPUT VIEW                         #######
##############################################################
def input(request):
    return render(request,'inputPage.html')
##############################################################
#######            MAKE DTAE COMPARABLE FUNCTION       #######
##############################################################
def get_date_count(input_string):
    inputstr=str(input_string)
    base=2018
    array = inputstr.split('/')
    y = int(array[2])
    m = int(array[0])
    d = int(array[1])
    diff=y-base
    # print(diff)
    if(diff==0):
        days=0
    else:
        days=365*diff
    #print(days)
    if(m==1):   #jan
        days=days+0
    elif(m==2):   #feb
        days=days+31
    elif(m==3):   #march
        days=days+31+28
    elif(m==4):    #april
        days=days+31+28+31
    elif(m==5):    #may
        days=days+31+28+31+30
    elif(m==6):    #june
        days=days+31+28+31+30+31
    elif(m==7):    #july
        days=days+31+28+31+30+31+30
    elif(m==8):    #august
        days=days+31+28+31+30+31+30+31
    elif(m==9):    #september
        days=days+31+28+31+30+31+30+31+31
    elif(m==10):    #october
        days=days+31+28+31+30+31+30+31+31+30
    elif(m==11):    #november
        days=days+31+28+31+30+31+30+31+31+30+31
    elif(m==12):    #december
        days=days+31+28+31+30+31+30+31+31+30+31+30
    days = days + d
    return days
def clean(request):
#######################################################################################################
###############     GETTING THE FORM INFORMATION FROM USER INTERFACE                   ###############
######################################################################################################
    if request.method == 'POST':
        class Testd:
            def __init__(self,date,count1):
                self.d = date
                self.c = count1
        global starting,ending
        sw = request.POST['sw']
        fromDate = request.POST['fromDate']
        toDate = request.POST['toDate']
        starting = fromDate
        ending = toDate
        start_date_count = get_date_count(starting)
        end_date_count = get_date_count(ending)
        #######################################################################################################
        ###############                       GETTING INTERVAL DATE OBJECT                     ###############
        ######################################################################################################
        temp_list = []
        for counter in list(models.Tekla.objects.all()):
            new_dates1 = get_date_count(counter.date)
            if(new_dates1 >= start_date_count and new_dates1 <= end_date_count):
                temp_list.append(counter)
        global var_temp,obj2_list
        var_temp = temp_list
        #######################################################################################################
        ###############     GETTING UNIQE DATES FROM INTERVAL FOEM OBJECT  AND COUNT NO OF IN           ######
        ######################################################################################################
        unique_dates = []
        for counter in temp_list:
            unique_dates.append(str(counter.date))
        unique_dates = set(sorted(unique_dates))
        print(unique_dates)

        for date in unique_dates:
            date_objects = models.Tekla.objects.filter(status="OUT").filter(date=date)
            un_time = []
            for time_object in date_objects:
                un_time.append(str(time_object.time))
            count = len(set(un_time))
            obj2_list.append(Testd(add_date_style(str(date)),count))
#######################################################################################################
###############              LICENCE AVAILIBLITY                                        ###############
#######################################################################################################
    print("OUT OF THE POST METHOD")
    total = 0    #total lience.
    current = 0  #available licence.
    bat_file_path =os.path.join("E:\django_project\license_tool\logs and data\Tekla_Usage.txt")
    #bat_file_path =os.path.join("\ad001.siemens.net\dfs001\Custom\Siemens_India\Misc\Public\CAD\PDSLicenseStatus\Tekla_Usage.txt")
    read_bat_file = open(bat_file_path,'r')
    bat_file_content = read_bat_file.readlines()
    read_bat_file.close()
    count = 1
    count = 0
    for key in bat_file_content:
        count = count+1
        key = key.rstrip(os.linesep)

        find_text1 = re.search( r'\s*Total number of Tekla license in use out of (\d+)', key, re.I)
        if find_text1:
             total = find_text1.group(1)
        find_text2 = re.search( r'(\d+)', key, re.I)
        if find_text2:
             current = find_text2.group(1)

    class Testd:
        def __init__(self,date,count):
            self.d = date
            self.c = count

#######################################################################################################
###############                  USER LOGS                                               ##############
######################################################################################################
    obj_list = []
    unique_dates1 = []
    dates2= list(models.Tekla.objects.all())
    for counter in dates2:
        d1 = counter.date
        unique_dates1.append(str(d1))

    unique_dates1 = set(sorted(unique_dates1))
    for date in unique_dates1:
        date_objects = models.Tekla.objects.filter(status="IN").filter(date=date)
        un_time = []
        for time_object in date_objects:
            un_time.append(str(time_object.time))
        count = len(set(un_time))
        obj_list.append(Testd(add_date_style(str(date)),count))
#######################################################################################################
###############    CURRENT ACTIVE USER INFORMATION                                      ###############
######################################################################################################
        bat_file =os.path.join("E:\django_project\license_tool\logs and data\Tekla_Usage.txt")
        #bat_file =os.path.join("\ad001.siemens.net\dfs001\Custom\Siemens_India\Misc\Public\CAD\PDSLicenseStatus\Tekla_Usage.txt")
        #print("log_file_path : " +bat_file_path
        read_bat= open(bat_file,'r')
        bat_file_data = read_bat.readlines()
        read_bat.close()
        #print("starting to read lines")
        test = []
        for line in bat_file_data:
            line = line.rstrip(os.linesep)

            find_show=re.search( r'\s+(.*start.*)', line, re.I)
            if find_show:
                vu=find_show.group(1)
                test.append(vu)
#######################################################################################################
###############     COUNTING THE NO OF DIFFERENT USERS  FOR THE GIVEN TIME INTERVAL   ################
######################################################################################################
    print("this is all okk.-----------------------------------")
    class Testdd:
        def __init__(self,date,count,users):
            self.d = date
            self.c = count
            self.u = users

    start_date_count = get_date_count(starting)
    end_date_count = get_date_count(ending)
    un_dates = []
    model_list = models.Tekla.objects.filter(status="OUT")
    for counter in model_list:
        d1 = counter.date
        new_dates1 = get_date_count(str(d1))
        if(new_dates1 >= start_date_count and new_dates1 <= end_date_count):
            un_dates.append(str(d1))
    un_dates = set(sorted(un_dates)) #unique dates
    print(un_dates)
    user_date_list = []
    def make_string(strings):
        result = ""
        for string in strings:
            result += str(string)+','
        return result
    all_users = []
    for d in un_dates:
        s_object = model_list.filter(date = d)
        count = []
        for o in s_object:
            count.append(str(o.user_Id))
            all_users.append(o.user_Id)
##############     COUNT IS THE ALL THE USERS IN THE GIVEN INTERVAL    ###############################
        users = make_string(set(count))
        count = len(set(count))
        user_date_list.append(Testdd(d,count,users))
    all_un_users = set(all_users)
    class Tempo:
        def __init__(self,user,count):
            self.c = count
            self.u = user
    user_access_list = []
    for user in all_un_users:
        count_access = 0
        mod = models.Tekla.objects.filter(status="IN").filter(user_Id = user)
        for counter in mod:
            d1 = counter.date
            new_dates1 = get_date_count(d1)
            if(new_dates1 >= start_date_count and new_dates1 <= end_date_count):
                count_access+=1
        user_access_list.append(Tempo(user,count_access))
        print(user,count_access)
#######################################################################################################
###############     COUNTING THE NO OF DIFFERENT USERS  AND THERE ACCESS               ###############
######################################################################################################

    if request.method == 'POST':
        return render(request,'homePageAdmin.html',context={'object_list':var_temp,'ob_list':obj2_list,'t':total,'cu':current,'dat1':test,'user_date_list':user_date_list,'user_access_list':user_access_list})
    else:
        return render(request,'homePageAdmin.html',context={'object_list':models.Tekla.objects.all(),'ob_list':obj_list,'t':total,'cu':current,'dat1':test,'user_date_list':user_date_list,'user_access_list':user_access_list})


@login_required
def check_login(request):
    if request.method == 'POST':

        # First get the username and password supplied
        username = request.POST.get('username')
        password = request.POST.get('password')
        print ("username : " + username)
        print("password : " + password)

        # Django's built-in authentication function:
        user = authenticate(username=username, password=password)

        # If we have a user
        if user:
            #Check it the account is active
            if user.is_active:
                print("login Successful . user logged in sccuessfully")
                # Log the user in.
                login(request,user)
                return input(request)
            else:
                print("user is currently inactive")
                return login_failed_page(request,"user is currently inactive")

        else:
            print("Someone tried to login and failed.")
            print("They used username: {} and password: {}".format(username,password))
            error_message="They used username: {} and password: {}".format(username,password)
            # return HttpResponse("Invalid login details supplied.")
            return login_failed_page(request,error_message)

    # my_dict = {'insert_me':"index_login!"}
    # return render(request,'user_login.html',context=my_dict)
    print("user didnt come from correct path.")
    return login_failed_page(request,"user didnt come from correct path.")

@login_required
def login_failed_page(request,error_message):

    return render(request,'loginPage.html')

def export(request):
        global starting,ending
        print(starting)
        # print(starting,ending)
        start_date_count = get_date_count(starting)
        end_date_count = get_date_count(ending)
        response = HttpResponse(content_type='text/csv')
        # response1 = HttpResponse(content_type='text/pdf')
        response['Content-Disposition'] = 'attachment; filename="abc.csv"'

        # print(start_date_count)
        # print(end_date_count)
        writer = csv.writer(response)
        writer.writerow(['Date', 'Time', 'Feature', 'Status', 'Feature-ID','User-ID','Host-ID'])
        # print("FFFFFFFFFFFFFFFFFFFFFFFFFF")
        dates1 = list(models.Tekla.objects.all())
        for counter in dates1:
            d1=counter.date
            new_dates1=get_date_count(d1)
            # print(new_dates1)
            if(new_dates1 >= start_date_count and new_dates1 <= end_date_count):
                writer.writerow([counter.date, counter.time, counter.feature, counter.status, counter.feature_Id, counter.user_Id,counter.host_ID])

        return response

def export_pdf(request):
        global starting,ending
        # print(starting,ending)
        start_date_count = get_date_count(starting)
        end_date_count = get_date_count(ending)
        response = HttpResponse(content_type='text/PDF')
        response['Content-Disposition'] = 'attachment; filename="abc.pdf"'
        writer = csv.writer(response)
        writer.writerow(['Date', 'Time', 'Feature', 'Status', 'Feature-ID','User-ID','Host-ID'])
        dates1 = list(models.Tekla.objects.all())
        for counter in dates1:
            d1=counter.date
            new_dates1=get_date_count(d1)
            if(new_dates1 >= start_date_count and new_dates1 <= end_date_count):
                writer.writerow([counter.date, counter.time, counter.feature, counter.status, counter.feature_Id, counter.user_Id,counter.host_ID])
        return response
######################################################################################################
###############                         USER LOGS                                        #############
######################################################################################################
def gen_search(request):
    temp = 0
    if request.method == 'POST':
        id = request.POST.get('user')
        global starting,ending
        start_date_count = get_date_count(starting)
        end_date_count = get_date_count(ending)
        d2 = models.Tekla.objects.filter(status="IN").filter(user_Id=id)
        for counter in d2:
            d1 = counter.date
            new_dates1 = get_date_count(d1)
            print(new_dates1)
            print(start_date_count)
            print(end_date_count)
            if(new_dates1 >= start_date_count and new_dates1 <= end_date_count):
                temp = temp+1
        print(temp)
    return render(request,'homePageAdmin.html',context={'obj22':temp})
