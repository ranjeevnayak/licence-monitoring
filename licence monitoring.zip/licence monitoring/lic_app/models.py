from django.db import models

class Testing(models.Model):
    name=models.CharField(max_length=264)
    def __str__(self):
        return self.name

class Tekla(models.Model):
    date = models.CharField(max_length=264)
    time = models.CharField(max_length=264)
    feature = models.CharField(max_length=264)
    status = models.CharField(max_length=264)
    feature_Id = models.CharField(max_length=264)
    user_Id = models.CharField(max_length=264)
    host_ID = models.CharField(max_length=264)

    def __str__(self):
        return self.host_ID

class authentication(models.Model):
    User_ID=models.CharField(max_length=264,unique=True)
    Password=models.CharField(max_length=264)
    Access=models.CharField(max_length=264)
    Dept=models.CharField(max_length=264)
    Software=models.CharField(max_length=264)
    
    def ___str__(self):
        return self.User_ID

class Tekla_user(models.Model):
    date=models.CharField(max_length=264)
    no_of_accesses=models.IntegerField(default=0,unique=True)
    def __str__(self):
        return self.no_of_accesses


# class export_data(models.Model):
