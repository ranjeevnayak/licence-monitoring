from django.conf.urls import url
from lic_app import views
from django.urls import path
# SET THE NAMESPACE!
app_name = 'lic_app'

# Becareful setting the name to just /login use userlogin instead!

urlpatterns=[
    url(r'^front/$',views.front,name='front'),
    url(r'^input/$',views.input,name='input'),
    url(r'^in/$',views.clean,name='home'),
    url(r'^login/$',views.clean,name='home'),
    url(r'^check_login/$',views.check_login,name='check_login'),
    url(r'^check/$',views.get_date_count,name='cn'),
    url(r'^export/$',views.export,name='exp'),
    url(r'^pdf/$',views.export_pdf,name='exp_pdf'),
    # url(r'^t/$',views.gen_search,name='t1'),
    #url(r'^inn/$',views.input_form_req,name='house'),
    # url(r'^aurth/$',views.input,name='h1'),
    #url(r'^show/$',views.show_status,name='home'),
    #url(r'^ghi/$',views.final,name='home'),
    #url(r'^out/$',views.show_db,name='home'),

     # url(r'^out/$',views.clean,name='home'),
    # url(r'^in1/$',views.status_display,name='home'),
    #path('',views.PageView.as_view(),name='home'),



]
